const express = require('express');
const mysql = require('mysql2/promise');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Configuração do banco de dados
const dbConfig = {
  host: 'localhost',
  user: 'root',
  password: 'chittaero',
  database: 'scriptTCC',
};

// Middleware para analisar o corpo das solicitações
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());


//Rota para lidar com o envio do formulário de login
app.post('/login', async (req, res) => {
  console.log('Corpo da requisição:', req.body);
  console.log('Valor do radio: ', req.body.radio);
  const { email, senha } = req.body;
  const tipoConta = req.body.radio;

  // Conectar ao banco de dados
  const connection = await mysql.createConnection(dbConfig);

  try {
    let rows;

    if (tipoConta === 'admin') {
      // Se for administrador, consulta na tabela 'Administrador'
      [rows] = await connection.execute(
        `SELECT * FROM Administrador WHERE Email = ? AND Senha = ?`,
        [email, senha]
      );
    } else {
      // Se for usuário comum, consulta na tabela 'Usuario'
      [rows] = await connection.execute(
        `SELECT * FROM Usuario WHERE Email = ? AND Senha = ?`,
        [email, senha]
      );
    }

    if (rows.length > 0) {
      // Usuário/administrador autenticado com sucesso
      if (tipoConta === 'admin') {
        res.redirect('/dashboard');
      } else {
        res.redirect('/homepage');
      }
    } else {
      // Credenciais inválidas
      res.status(401).send('Credenciais inválidas.');
    }
  } catch (error) {
    console.error('Erro ao realizar o login:', error.message);
    res.status(500).send('Erro ao realizar o login.');
  } finally {
    // Fechar a conexão com o banco de dados
    await connection.end();
  }
});


// Rota para lidar com o envio do formulário de registro
app.post('/register', async (req, res) => {
  const { nome, email, senha } = req.body;

  // Verifica se todos os campos necessários estão presentes e são strings
  if (nome && typeof nome === 'string' && email && typeof email === 'string' && senha && typeof senha === 'string') {
    // Conectar ao banco de dados
    const connection = await mysql.createConnection(dbConfig);

    try {
      // Inserir o novo usuário na tabela
      const [result] = await connection.execute(
        'INSERT INTO Usuario (Nome, Email, Senha) VALUES (?, ?, ?)',
        [nome, email, senha]
      );

      console.log('Novo usuário registrado com sucesso!');
      console.log('ID do novo usuário:', result.insertId);

      res.send('Usuário registrado com sucesso.')
    } catch (error) {
      console.error('Erro ao registrar o usuário:', error.message);
      res.status(500).send({ success: false, message: 'Erro ao registrar o usuário.' });
    } finally {
      // Fechar a conexão com o banco de dados
      await connection.end();
    }
  } else {
    res.status(400).send({ success: false, message: 'Parâmetros ausentes ou inválidos.' });
  }
});

// Rota para a página inicial
app.use('/homepage', express.static('homepage'));
app.get('/homepage', (req, res) => {
  res.sendFile(__dirname + '/homepage/index.html');
});

// Rota dashboard
app.use('/dashboard', express.static('dashboard'));
app.get('/dashboard', (req, res) => {
  res.sendFile(__dirname + '/dashboard/index.html');
});

// Rota formulário
app.use('/forms', express.static('forms'));
app.get('/forms', (req, res) => {
  res.sendFile(__dirname + '/forms/index.html');
});

// Rota para a página de login
app.use('/login', express.static('login'));
app.get('/login', (req, res) => {
  res.sendFile(__dirname + '/login/index.html');
});

// Inicia o servidor na porta especificada
app.listen(port, () => {
  console.log(`Servidor web está rodando em http://localhost:${port}`);
});
