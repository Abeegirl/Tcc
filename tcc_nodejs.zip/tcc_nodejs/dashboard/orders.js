const Orders = [
    {
        productName: 'Julio Cesar',
        productNumber: '85743',
        paymentStatus: 'Saúde Integrada',
        status: 'Esperando'
    },
    {
        productName: 'Gabriele Silva',
        productNumber: '97245',
        paymentStatus: 'Expocanp...',
        status: 'Negado'
    },
    {
        productName: 'Gabriel Gil',
        productNumber: '36452',
        paymentStatus: 'Interclasse',
        status: 'Aceito'
    },
]