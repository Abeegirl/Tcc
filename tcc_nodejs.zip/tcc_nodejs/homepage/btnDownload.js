// Função global para download
function Download() {
    // Obtém o elemento pai do botão de download (que contém a imagem)
    var postContainer = document.getElementById('download').closest('.post-container');

    // Obtém a URL da imagem dentro do postContainer
    var imageUrl = postContainer.querySelector('.cover').src;

    // Cria um link temporário
    var a = document.createElement('a');
    a.href = imageUrl;
    a.download = 'imagem.jpg'; // Nome do arquivo a ser baixado

    // Adiciona o link temporário ao corpo da página e simula o clique nele
    document.body.appendChild(a);
    a.click();

    // Remove o link temporário
    document.body.removeChild(a);
}
